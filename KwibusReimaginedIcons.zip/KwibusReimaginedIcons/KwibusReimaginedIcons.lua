local ADDON_NAME  = "KwibusReimaginedIcons"

local ADDON_ICONS_PATH = "/KwibusReimaginedIcons/icons/"

local ADDON_ICONS = {
    "ability_templar_extended_ritual.dds",
    "ability_templarsun_thrust.dds",
    "ability_templar_persistant_sigil.dds",
    "ability_templar_purifying_light.dds",
    "ability_templar_solar_power.dds",
    "ability_templar_under_exposure.dds",
    "ability_templar_vampire_bane.dds",
    "ability_templar_reckless_attacks.dds",
    "ability_necromancer_001_a.dds",
    "ability_necromancer_002_a.dds",
    "ability_necromancer_004_a.dds",
    "ability_necromancer_005_b.dds",
    "ability_necromancer_006_a.dds",
    "ability_necromancer_007_a.dds",
    "ability_necromancer_008_a.dds",
    "ability_necromancer_008_b.dds",
    "ability_necromancer_009_b.dds",
    "ability_necromancer_011_b.dds",
    "ability_necromancer_015_a.dds",
    "ability_necromancer_015_b.dds",
    "ability_arcanist_002_a.dds",
    "ability_arcanist_002_b.dds",
    "ability_arcanist_002.dds",
    "ability_restorationstaff_002a.dds",
    "ability_restorationstaff_003_b.dds",
    "ability_restorationstaff_004b.dds",
    "ability_fightersguild_001_b.dds",
    "ability_fightersguild_004_a.dds",
    "ability_fightersguild_005_a.dds",
    "ability_fightersguild_002_b.dds",
    "ability_psijic_001_b.dds",
    "ability_ava_echoing_vigor.dds",
    "ability_ava_006_a.dds",
    "ability_ava_006_b.dds",
    "ability_ava_revealing_flare.dds",
    "ability_dragonknight_001_b.dds",
    "ability_necromancer_002_b.dds",
    "ability_necromancer_002.dds",
    "ability_grimoire_support_physical.dds",
    "ability_necromancer_012.dds",
}

-- Function to initialize icons
local function InitializeIcons()
    if AbilityIconsFramework and AbilityIconsFramework.AddCustomIconPack then
        -- Add the custom icon pack
        AbilityIconsFramework.AddCustomIconPack(ADDON_ICONS_PATH, ADDON_ICONS)
    else
        d("KwibusReimaginedIcons: AbilityIconsFramework not found or incompatible!")
    end
end


-- Initialize icons when the addon is loaded
EVENT_MANAGER:RegisterForEvent(ADDON_NAME, EVENT_ADD_ON_LOADED, function(_, addonName)
    if addonName ~= ADDON_NAME then return end
    EVENT_MANAGER:UnregisterForEvent(ADDON_NAME, EVENT_ADD_ON_LOADED)
    InitializeIcons()
end)